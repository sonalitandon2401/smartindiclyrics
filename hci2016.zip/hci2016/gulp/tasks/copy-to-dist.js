'use strict';

var gulp = require('gulp');

gulp.task('copy-to-dist', ['copy-markup', 'copy-assets', 'copy-utils']);