'use strict';

var gulp = require('gulp'),
	runSequence = require('run-sequence');

gulp.task('default', function() {
	runSequence('clean-dist', ['bundle-js', 'bundle-css', 'watch'], 'copy-to-dist', 'serve');
	// This means that clean-dist task will run first, followed by 'set-watch'. Next, the group ['bundle-js', 'bundle-css', 'watch'] will run. Within the group, the tasks can run in parallel. This is followed by copy-to-dist and serve.
});