'use strict';

var
// define all the requires
	gulp = require('gulp'),
	gulpif = require('gulp-if'),
	browserSync = require('browser-sync'),
	browserify = require('browserify'),
	watchify = require('watchify'),
	uglify = require('gulp-uglify'),
	bundleLogger = require('../util/bundle-logger'),
	handleErrors = require('../util/handle-errors'),
	es = require('event-stream'),
	buffer = require('vinyl-buffer'),
	sourcemaps = require('gulp-sourcemaps'),
	source = require('vinyl-source-stream'),
	rename = require('gulp-rename'),
	ngAnnotate = require('gulp-ng-annotate'),
	yargs = require('yargs'),
	config = require('../config'),

	// local variables
	production;

// gulp build --production
production = !!yargs.argv.production;

gulp.task('bundle-js', function(callback) {
	var bundleQueue, browserifyThis;

	bundleQueue = config.bundleConfigs.length;
	browserifyThis = function(bundleConfig) {
		var bundler, bundle;

		bundler = browserify({
			cache: {},
			packageCache: {},
			fullPaths: false,
			entries: bundleConfig.entries,
			extensions: config.extensions,
			debug: bundleConfig.debug,
			standalone: bundleConfig.standalone
		});

		bundle = function() {
			var aBundle, normal, min;

			// Log when bundling starts
			bundleLogger.start(bundleConfig.outputName);

			aBundle = bundler
				.bundle()
				.on('error', handleErrors);

			normal = aBundle
				.pipe(source(bundleConfig.outputName))
				.pipe(buffer())
				.pipe(gulpif(bundleConfig.debug, sourcemaps.init({
					loadMaps: true
				})))
				.pipe(ngAnnotate())
				.pipe(gulpif(bundleConfig.debug, sourcemaps.write('./')))
				.pipe(gulp.dest(config.destConfig.js))
				.pipe(browserSync.reload({
					stream: true
				}));

			min = aBundle
				.pipe(gulpif(production, source(bundleConfig.outputName)))
				.pipe(gulpif(production, buffer()))
				.pipe(gulpif(production, rename({
					suffix: '.min'
				})))
				.pipe(gulpif(production && bundleConfig.debug, sourcemaps.init({
					loadMaps: true
				})))
				.pipe(gulpif(production, ngAnnotate()))
				.pipe(gulpif(production, uglify()))
				.pipe(gulpif(production && bundleConfig.debug, sourcemaps.write('./')))
				.pipe(gulpif(production, gulp.dest(config.destConfig.js)))
				.on('end', reportFinished);

			return es.concat(normal, min);
		};

		function reportFinished() {
			bundleLogger.end(bundleConfig.outputName);

			if (bundleQueue) {
				bundleQueue--;
				if (bundleQueue === 0) {
					// If queue is empty, tell gulp the task is complete.
					// https://github.com/gulpjs/gulp/blob/master/docs/API.md#accept-a-callback
					callback();
				}
			}
		}

		return bundle();
	};

	config.bundleConfigs.forEach(browserifyThis);
});