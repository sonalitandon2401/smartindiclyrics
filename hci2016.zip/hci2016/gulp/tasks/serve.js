'use strict';

var gulp = require('gulp'),
	browserSync = require('browser-sync'),
	config = require('../config');

gulp.task('serve', ['fixture-server'], function() {
  browserSync({
    proxy: 'localhost:' + config.browserSyncConfig.proxyPort, // fixture server port
    startPath: config.browserSyncConfig.startPath,
    files: config.browserSyncConfig.destPath
  });
});