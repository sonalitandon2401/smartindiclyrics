'use strict';

var gulp = require('gulp'),
	clean = require('gulp-clean'),
	config = require('../config');

gulp.task('clean-dist', function() {
	return gulp.src(config.destConfig.dir, {
			// to restrict gulp from reading the contents, making it faster
			read: false
		})
		.pipe(clean());
});