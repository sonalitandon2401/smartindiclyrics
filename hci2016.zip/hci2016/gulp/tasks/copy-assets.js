'use strict';

var gulp = require('gulp'),
	config = require('../config');

gulp.task('copy-assets', function() {

	// Copy locales
	gulp.src([config.srcConfig.locales + '/**'])
		.pipe(gulp.dest(config.destConfig.locales));

	// Copy images
	gulp.src([config.srcConfig.img + '/**'])
		.pipe(gulp.dest(config.destConfig.img));

	// Copy audio files
	gulp.src([config.srcConfig.audio + '/**'])
		.pipe(gulp.dest(config.destConfig.audio));

	// Copy lyrics files
	gulp.src([config.srcConfig.langLyrics + '/**'])
		.pipe(gulp.dest(config.destConfig.langLyrics));

	// Copy lrc files
	gulp.src([config.srcConfig.lrcFiles + '/**'])
		.pipe(gulp.dest(config.destConfig.lrcFiles));

	// Copy js files
	gulp.src([config.srcConfig.customjs + '/**'])
		.pipe(gulp.dest(config.destConfig.customjs));

	// Copy css files
	gulp.src([config.srcConfig.customcss + '/**'])
		.pipe(gulp.dest(config.destConfig.customcss));

	// Copy css files
	gulp.src([config.srcConfig.svg + '/**'])
		.pipe(gulp.dest(config.destConfig.svg));

	// Copy css files
	gulp.src([config.srcConfig.fonts + '/**'])
		.pipe(gulp.dest(config.destConfig.fonts));
});