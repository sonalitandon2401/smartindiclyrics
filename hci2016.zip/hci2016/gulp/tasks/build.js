'use strict';

var gulp = require('gulp');

gulp.task('build', ['lint', 'bundle-js', 'bundle-css', 'copy-markup', 'copy-to-dist']);