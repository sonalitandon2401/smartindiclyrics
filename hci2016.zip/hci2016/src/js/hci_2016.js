import angular from 'angular';
import 'angular-ui-router';
import 'angular-ui-bootstrap';
import 'angular-animate';

let hci2016Module;

hci2016Module = angular.module('hci2016', [
	'ui.router',
	'ui.bootstrap',
	'ngAnimate'
]);

export default hci2016Module;