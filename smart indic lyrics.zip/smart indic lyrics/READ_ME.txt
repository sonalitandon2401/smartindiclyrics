Instructions to run:
Open the index.html in a browser of your choice and you are ready to go :)