Instructions to run the code:

1. npm install -> Its to download all the npm packages.
2. npm start in the project root directory.
3. A new tab will be launched, and the project is all set and running.
