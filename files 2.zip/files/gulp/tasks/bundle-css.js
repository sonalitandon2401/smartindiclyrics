'use strict';

var gulp = require('gulp'),
	gulpif = require('gulp-if'),
	sourcemaps = require('gulp-sourcemaps'),
	minifyCss = require('gulp-minify-css'),
	rename = require('gulp-rename'),
	sass = require('gulp-sass'),
	yargs = require('yargs'),
	config = require('../config'),

	// local variables
	production;

production = !!yargs.argv.production;

gulp.task('bundle-css', ['bundle-css:' + config.packageName]);

gulp.task('bundle-css:' + config.packageName, function() {
	return gulp.src(config.srcConfig.sass + '/' + config.packageName + '.scss')
		.pipe(sourcemaps.init())
		.pipe(sass())
		.on('error', function(error) {
			console.log(error);
			this.emit('end');
		})
		.pipe(gulp.dest(config.destConfig.css))
		.pipe(gulpif(production, minifyCss()))
		.pipe(gulpif(production, rename({
			suffix: '.min'
		})))
		.pipe(gulpif(production, sourcemaps.write('./')))
		.pipe(gulpif(production, gulp.dest(config.destConfig.css)))
		.on('end', function() {

		});
});