'use strict';

var gulp = require('gulp'),
	config = require('../config');

// copies markup to the dest directory
gulp.task('copy-markup', function() {
	return gulp.src([config.srcConfig.markup])
		.pipe(gulp.dest(config.destConfig.dir));
});