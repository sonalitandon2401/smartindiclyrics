'use strict';

var gulp = require('gulp'),
	fixtureServer = require('portal-fixture-server/server'),
	config = require('../config');

gulp.task('fixture-server', function(done) {
	fixtureServer.start(config.fixtureServerConfig);
	done();
});