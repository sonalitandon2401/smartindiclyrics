'use strict';

var gulp = require('gulp'),
	watch = require('gulp-watch'),
	config = require('../config');

gulp.task('watch', function() {
	watch(config.srcConfig.markup, function() {
		console.log('Markup changed!');
		gulp.start('copy-markup');
	});
	watch(config.srcConfig.assets, function() {
		console.log('Assets changed!');
		gulp.start('copy-assets');
	});
	watch([config.srcConfig.sass + '/*.scss', config.srcConfig.components + '/**/*.scss', config.srcConfig.shared + '/**/*.scss'], function() {
		console.log('Less files changed!');
		gulp.start('bundle-css');
	});

	watch([config.srcConfig.js + '/' + config.packageName + '.js',config.srcConfig.customjs + '/**.js', config.srcConfig.components + '/**/*.js', config.srcConfig.components + '/**/*.html', config.srcConfig.shared + '/**/*.js', config.srcConfig.shared + '/**/*.html'], function() {
	 	gulp.start('bundle-js');
	});
});