'use strict';

var gulp = require('gulp'),
	connect = require('gulp-connect'),
	modRewrite = require('connect-modrewrite'),
	gulpUtil = require('gulp-util'),
	config = require('../config');

gulp.task('connect', function() {
	connect
		.server({
			root: config.serverConfig.root,
			port: config.serverConfig.port,
			middleware: function() {
				return [
					modRewrite([
						'/apps/hci2016/dist'
					]),
					// sleep for sometime for all json requests
					function(req, res, next) {
						if (req.url.indexOf('.json') !== -1) {
							setTimeout(function() {
								next();
							}, 1000);
						} else {
							next();
						}
					},
					// handle POST/PUT requests
					function(req, res, next) {
						// define the set of sample responses and change the jsonStr accordingly to simulate different scenarios as required.
						var appConfig = {
											"access_token": "sdjt438tj9jq9efjsdf",
											"token_type": "bearer",
											"refresh_token": "23faa1db-3e36-4141-b2a3-f11f84e2b421",
											"expires_in": 43199,
											"scope": "read write"
										};

						// send the response body
						var jsonStr = JSON.stringify(appConfig);
						if (req.method !== 'GET') {
							res.writeHead(200, {
								'Content-Type': 'application/json; charset=utf-8',
								'Content-Length': Buffer.byteLength(jsonStr, 'utf-8')
							});
							res.write(jsonStr);
							res.end();
						}

						next();
					},
				];
			}
		});
});
