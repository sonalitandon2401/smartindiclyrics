'use strict';

//base config file that is 'required' into the gulp task

var // define all the requires
	pkg = require('../package.json'),
	path = require('path'),

	// local variables
	srcPath = './src',
	destPath = './dist',
	fixtureServerPort = 8000,
	packageName = pkg.name,
	jsFileName = packageName + '.js',
	srcConfig,
	destConfig,
	browserSyncConfig,
	fixtureServerConfig;

// configure the source configurations here
srcConfig = {
	dir: srcPath,
	locales: srcPath + '/assets/locales',
	localServices: srcPath + '/assets/localServices',
	js: srcPath + '/js',
	utils: srcPath + '/js/utils',
	components: srcPath + '/components',
	shared: srcPath + '/shared',
	sass: srcPath + '/sass',
	markup: srcPath + '/index.html',
	assets: srcPath + '/assets',
	audio: srcPath + '/audio',
	langLyrics: srcPath + '/langLyrics',
	lrcFiles: srcPath + '/lrcFiles',
	customcss: srcPath + '/customcss',
	customjs: srcPath + '/customjs',
	fonts: srcPath + '/fonts',
	img: srcPath + '/img',
	svg: srcPath + '/svg'
};

// configure the directory where you wish the distribution files should reside
destConfig = {
	dir: destPath,
	img: destPath + '/img',
	locales: destPath + '/locales',
	localServices: destPath + '/localServices',
	js: destPath + '/js',
	utils: destPath + '/js/utils',
	css: destPath + '/css',
	libs: destPath + '/libs',
	markup: destPath,
	audio: destPath + '/audio',
	langLyrics: destPath + '/langLyrics',
	lrcFiles: destPath + '/lrcFiles',
	customcss: destPath + '/customcss',
	customjs: destPath + '/customjs',
	fonts: destPath + '/fonts',
	svg: destPath + '/svg'
};

browserSyncConfig = {
	proxyPort: fixtureServerPort,
	startPath: '/apps/hci2016/',
	files: destPath
};

fixtureServerConfig = {
	staticPaths: {
		'/apps/hci2016/': 'dist'
	},
	routePath: path.resolve('gulp/fixtures/routes'),
	port: fixtureServerPort,
	apiTemplate: {
		httpStatus: 200
	},
	apiDelay: 2000
};

module.exports = {
	packageName: packageName,
	srcConfig: srcConfig,
	destConfig: destConfig,
	browserSyncConfig: browserSyncConfig,
	fixtureServerConfig: fixtureServerConfig,
	bundleConfigs: [{
		entries: [srcConfig.js + '/' + packageName],
		debug: true,
		dest: destPath,
		outputName: jsFileName
	}]
};